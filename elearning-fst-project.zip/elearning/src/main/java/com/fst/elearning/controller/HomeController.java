package com.fst.elearning.controller;

import com.fst.elearning.entity.Utilisateur;
import com.fst.elearning.service.UtilisateurService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final UtilisateurService utilisateurService;

    @GetMapping("/")
    public String home() {
        return "redirect:/catalogue";
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth) {
        if (auth == null) return "redirect:/auth/login";
        Utilisateur user = utilisateurService.findByEmail(auth.getName());
        return switch (user.getRole()) {
            case ADMIN     -> "redirect:/admin/dashboard";
            case FORMATEUR -> "redirect:/formateur/dashboard";
            case APPRENANT -> "redirect:/apprenant/dashboard";
        };
    }
}
