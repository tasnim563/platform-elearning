package com.fst.elearning.controller;

import com.fst.elearning.dto.RegistrationDTO;
import com.fst.elearning.entity.Utilisateur;
import com.fst.elearning.service.UtilisateurService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UtilisateurService utilisateurService;

    @GetMapping("/login")
    public String loginPage(@RequestParam(required = false) String error,
                            @RequestParam(required = false) String logout,
                            Model model) {
        if (error != null) model.addAttribute("error", "Email ou mot de passe incorrect.");
        if (logout != null) model.addAttribute("logout", "Vous avez été déconnecté.");
        return "auth/login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("registrationDTO", new RegistrationDTO());
        model.addAttribute("roles", new Utilisateur.Role[]{Utilisateur.Role.APPRENANT, Utilisateur.Role.FORMATEUR});
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute RegistrationDTO registrationDTO,
                           BindingResult result,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        if (!registrationDTO.isMotDePasseMatch()) {
            result.rejectValue("confirmMotDePasse", "error.confirmMotDePasse", "Les mots de passe ne correspondent pas.");
        }
        if (result.hasErrors()) {
            model.addAttribute("roles", new Utilisateur.Role[]{Utilisateur.Role.APPRENANT, Utilisateur.Role.FORMATEUR});
            return "auth/register";
        }
        try {
            utilisateurService.register(registrationDTO);
            redirectAttributes.addFlashAttribute("success", "Compte créé avec succès ! Vous pouvez vous connecter.");
            return "redirect:/auth/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("roles", new Utilisateur.Role[]{Utilisateur.Role.APPRENANT, Utilisateur.Role.FORMATEUR});
            return "auth/register";
        }
    }
}
