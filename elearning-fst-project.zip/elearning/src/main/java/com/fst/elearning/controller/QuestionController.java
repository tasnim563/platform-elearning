package com.fst.elearning.controller;

import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import com.fst.elearning.service.UtilisateurService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('FORMATEUR','ADMIN')")
public class QuestionController {

    private final QuizRepository quizRepo;
    private final LeconRepository leconRepo;
    private final UtilisateurService utilisateurService;

    @PostMapping("/formateur/quiz/{quizId}/questions/ajouter")
    public String ajouterQuestion(@PathVariable Long quizId,
                                  @RequestParam String enonce,
                                  @RequestParam String choixA,
                                  @RequestParam String choixB,
                                  @RequestParam String choixC,
                                  @RequestParam String choixD,
                                  @RequestParam char bonneReponse,
                                  RedirectAttributes redirectAttributes) {
        Quiz quiz = quizRepo.findById(quizId).orElseThrow();
        Question q = Question.builder()
            .quiz(quiz)
            .enonce(enonce)
            .choixA(choixA).choixB(choixB).choixC(choixC).choixD(choixD)
            .bonneReponse(bonneReponse)
            .build();
        quiz.getQuestions().add(q);
        quizRepo.save(quiz);
        redirectAttributes.addFlashAttribute("success", "Question ajoutée !");
        return "redirect:/formateur/modules/" + quiz.getModule().getId() + "/quiz";
    }
}
