package com.fst.elearning.controller;

import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import com.fst.elearning.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/formateur")
@PreAuthorize("hasAnyRole('FORMATEUR','ADMIN')")
@RequiredArgsConstructor
public class FormateurController {

    private final UtilisateurService utilisateurService;
    private final CoursService coursService;
    private final InscriptionService inscriptionService;
    private final ProgressionService progressionService;
    private final ModuleRepository moduleRepo;
    private final LeconRepository leconRepo;
    private final QuizRepository quizRepo;

    private Utilisateur getCurrentUser(Authentication auth) {
        return utilisateurService.findByEmail(auth.getName());
    }

    // ---- Dashboard ----
    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        Utilisateur user = getCurrentUser(auth);
        List<Cours> mesCours = coursService.findByFormateur(user);
        int totalInscrits = mesCours.stream()
            .mapToInt(c -> inscriptionService.findByCours(c).size()).sum();
        model.addAttribute("user", user);
        model.addAttribute("mesCours", mesCours);
        model.addAttribute("totalInscrits", totalInscrits);
        return "formateur/dashboard";
    }

    // ---- Cours CRUD ----
    @GetMapping("/cours/nouveau")
    public String nouveauCoursForm(Model model) {
        model.addAttribute("cours", new Cours());
        model.addAttribute("niveaux", Cours.Niveau.values());
        return "formateur/cours-form";
    }

    @PostMapping("/cours/nouveau")
    public String creerCours(@Valid @ModelAttribute Cours cours,
                             BindingResult result,
                             @RequestParam(required = false) MultipartFile image,
                             Authentication auth, Model model,
                             RedirectAttributes redirectAttributes) throws IOException {
        if (result.hasErrors()) {
            model.addAttribute("niveaux", Cours.Niveau.values());
            return "formateur/cours-form";
        }
        cours.setFormateur(getCurrentUser(auth));
        coursService.save(cours, image);
        redirectAttributes.addFlashAttribute("success", "Cours créé avec succès !");
        return "redirect:/formateur/dashboard";
    }

    @GetMapping("/cours/{id}/modifier")
    public String modifierCoursForm(@PathVariable Long id, Authentication auth, Model model) {
        Cours cours = coursService.findById(id);
        verifierProprietaire(cours, getCurrentUser(auth));
        model.addAttribute("cours", cours);
        model.addAttribute("niveaux", Cours.Niveau.values());
        return "formateur/cours-form";
    }

    @PostMapping("/cours/{id}/modifier")
    public String modifierCours(@PathVariable Long id,
                                @Valid @ModelAttribute Cours coursForm,
                                BindingResult result,
                                @RequestParam(required = false) MultipartFile image,
                                Authentication auth, Model model,
                                RedirectAttributes redirectAttributes) throws IOException {
        if (result.hasErrors()) {
            model.addAttribute("niveaux", Cours.Niveau.values());
            return "formateur/cours-form";
        }
        Cours cours = coursService.findById(id);
        verifierProprietaire(cours, getCurrentUser(auth));
        cours.setTitre(coursForm.getTitre());
        cours.setDescription(coursForm.getDescription());
        cours.setCategorie(coursForm.getCategorie());
        cours.setNiveau(coursForm.getNiveau());
        cours.setActif(coursForm.isActif());
        coursService.save(cours, image);
        redirectAttributes.addFlashAttribute("success", "Cours mis à jour !");
        return "redirect:/formateur/cours/" + id + "/modules";
    }

    @PostMapping("/cours/{id}/supprimer")
    public String supprimerCours(@PathVariable Long id, Authentication auth,
                                 RedirectAttributes redirectAttributes) {
        Cours cours = coursService.findById(id);
        verifierProprietaire(cours, getCurrentUser(auth));
        coursService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Cours supprimé.");
        return "redirect:/formateur/dashboard";
    }

    // ---- Modules ----
    @GetMapping("/cours/{coursId}/modules")
    public String gererModules(@PathVariable Long coursId, Authentication auth, Model model) {
        Cours cours = coursService.findById(coursId);
        verifierProprietaire(cours, getCurrentUser(auth));
        model.addAttribute("cours", cours);
        model.addAttribute("nouveauModule", new Module());
        return "formateur/modules";
    }

    @PostMapping("/cours/{coursId}/modules/ajouter")
    public String ajouterModule(@PathVariable Long coursId,
                                @Valid @ModelAttribute("nouveauModule") Module module,
                                BindingResult result, Authentication auth,
                                RedirectAttributes redirectAttributes) {
        Cours cours = coursService.findById(coursId);
        verifierProprietaire(cours, getCurrentUser(auth));
        if (!result.hasErrors()) {
            module.setCours(cours);
            if (module.getOrdre() == 0) module.setOrdre(moduleRepo.countByCours(cours) + 1);
            moduleRepo.save(module);
            redirectAttributes.addFlashAttribute("success", "Module ajouté !");
        }
        return "redirect:/formateur/cours/" + coursId + "/modules";
    }

    @PostMapping("/modules/{moduleId}/supprimer")
    public String supprimerModule(@PathVariable Long moduleId, Authentication auth,
                                  RedirectAttributes redirectAttributes) {
        Module module = moduleRepo.findById(moduleId).orElseThrow();
        verifierProprietaire(module.getCours(), getCurrentUser(auth));
        Long coursId = module.getCours().getId();
        moduleRepo.delete(module);
        redirectAttributes.addFlashAttribute("success", "Module supprimé.");
        return "redirect:/formateur/cours/" + coursId + "/modules";
    }

    // ---- Leçons ----
    @GetMapping("/modules/{moduleId}/lecons")
    public String gererLecons(@PathVariable Long moduleId, Authentication auth, Model model) {
        Module module = moduleRepo.findById(moduleId).orElseThrow();
        verifierProprietaire(module.getCours(), getCurrentUser(auth));
        model.addAttribute("module", module);
        model.addAttribute("cours", module.getCours());
        model.addAttribute("nouvelleLecon", new Lecon());
        return "formateur/lecons";
    }

    @PostMapping("/modules/{moduleId}/lecons/ajouter")
    public String ajouterLecon(@PathVariable Long moduleId,
                               @Valid @ModelAttribute("nouvelleLecon") Lecon lecon,
                               BindingResult result, Authentication auth,
                               RedirectAttributes redirectAttributes) {
        Module module = moduleRepo.findById(moduleId).orElseThrow();
        verifierProprietaire(module.getCours(), getCurrentUser(auth));
        if (!result.hasErrors()) {
            lecon.setModule(module);
            if (lecon.getOrdre() == 0) lecon.setOrdre(leconRepo.countByModule(module) + 1);
            leconRepo.save(lecon);
            redirectAttributes.addFlashAttribute("success", "Leçon ajoutée !");
        }
        return "redirect:/formateur/modules/" + moduleId + "/lecons";
    }

    @PostMapping("/lecons/{leconId}/supprimer")
    public String supprimerLecon(@PathVariable Long leconId, Authentication auth,
                                 RedirectAttributes redirectAttributes) {
        Lecon lecon = leconRepo.findById(leconId).orElseThrow();
        Long moduleId = lecon.getModule().getId();
        verifierProprietaire(lecon.getModule().getCours(), getCurrentUser(auth));
        leconRepo.delete(lecon);
        redirectAttributes.addFlashAttribute("success", "Leçon supprimée.");
        return "redirect:/formateur/modules/" + moduleId + "/lecons";
    }

    // ---- Quiz ----
    @GetMapping("/modules/{moduleId}/quiz")
    public String gererQuiz(@PathVariable Long moduleId, Authentication auth, Model model) {
        Module module = moduleRepo.findById(moduleId).orElseThrow();
        verifierProprietaire(module.getCours(), getCurrentUser(auth));
        model.addAttribute("module", module);
        model.addAttribute("quiz", module.getQuiz());
        model.addAttribute("nouveauQuiz", new Quiz());
        return "formateur/quiz";
    }

    @PostMapping("/modules/{moduleId}/quiz/creer")
    public String creerQuiz(@PathVariable Long moduleId, @ModelAttribute Quiz quiz,
                            Authentication auth, RedirectAttributes redirectAttributes) {
        Module module = moduleRepo.findById(moduleId).orElseThrow();
        verifierProprietaire(module.getCours(), getCurrentUser(auth));
        quiz.setModule(module);
        quizRepo.save(quiz);
        redirectAttributes.addFlashAttribute("success", "Quiz créé !");
        return "redirect:/formateur/modules/" + moduleId + "/quiz";
    }

    // ---- Inscrits ----
    @GetMapping("/cours/{coursId}/inscrits")
    public String voirInscrits(@PathVariable Long coursId, Authentication auth, Model model) {
        Cours cours = coursService.findById(coursId);
        verifierProprietaire(cours, getCurrentUser(auth));
        List<Inscription> inscriptions = inscriptionService.findByCours(cours);
        model.addAttribute("cours", cours);
        model.addAttribute("inscriptions", inscriptions);
        return "formateur/inscrits";
    }

    private void verifierProprietaire(Cours cours, Utilisateur user) {
        if (user.getRole() == Utilisateur.Role.ADMIN) return;
        if (!cours.getFormateur().getId().equals(user.getId())) {
            throw new RuntimeException("Accès non autorisé");
        }
    }
}
