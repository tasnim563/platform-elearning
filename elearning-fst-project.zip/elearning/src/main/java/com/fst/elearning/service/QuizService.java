package com.fst.elearning.service;

import com.fst.elearning.dto.QuizResultDTO;
import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional
public class QuizService {

    private final QuizRepository quizRepo;
    private final ReponseApprenantRepository reponseRepo;

    @Transactional(readOnly = true)
    public Quiz findById(Long id) {
        return quizRepo.findById(id).orElseThrow(() -> new RuntimeException("Quiz non trouvé"));
    }

    public QuizResultDTO soumettre(Utilisateur apprenant, Long quizId, Map<Long, Character> reponses) {
        Quiz quiz = findById(quizId);
        int score = 0;
        for (Question q : quiz.getQuestions()) {
            Character rep = reponses.get(q.getId());
            if (rep != null && rep == q.getBonneReponse()) score++;
        }
        int total = quiz.getQuestions().size();

        ReponseApprenant ra = reponseRepo.findByApprenantAndQuiz(apprenant, quiz)
            .orElse(ReponseApprenant.builder().apprenant(apprenant).quiz(quiz).build());
        ra.setScore(score);
        ra.setTotalQuestions(total);
        reponseRepo.save(ra);

        return QuizResultDTO.builder()
            .quizId(quiz.getId())
            .quizTitre(quiz.getTitre())
            .moduleTitre(quiz.getModule().getTitre())
            .coursTitre(quiz.getModule().getCours().getTitre())
            .score(score).totalQuestions(total)
            .pourcentage(total == 0 ? 0 : (double) score / total * 100)
            .reussi(total > 0 && (double) score / total >= 0.6)
            .build();
    }

    @Transactional(readOnly = true)
    public Optional<ReponseApprenant> findResultat(Utilisateur apprenant, Quiz quiz) {
        return reponseRepo.findByApprenantAndQuiz(apprenant, quiz);
    }
}
