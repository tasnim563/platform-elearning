package com.fst.elearning.repository;
import com.fst.elearning.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ModuleRepository extends JpaRepository<Module, Long> {
    List<Module> findByCoursOrderByOrdreAsc(Cours cours);
    int countByCours(Cours cours);
}
