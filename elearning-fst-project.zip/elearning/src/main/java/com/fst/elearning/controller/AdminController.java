package com.fst.elearning.controller;

import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import com.fst.elearning.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminController {

    private final UtilisateurService utilisateurService;
    private final CoursService coursService;
    private final InscriptionRepository inscriptionRepo;

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        model.addAttribute("user", utilisateurService.findByEmail(auth.getName()));
        model.addAttribute("nbCours", coursService.countActifs());
        model.addAttribute("nbApprenants", utilisateurService.countByRole(Utilisateur.Role.APPRENANT));
        model.addAttribute("nbFormateurs", utilisateurService.countByRole(Utilisateur.Role.FORMATEUR));
        model.addAttribute("nbInscrits", inscriptionRepo.countByStatut(Inscription.Statut.EN_COURS));
        model.addAttribute("nbTermines", inscriptionRepo.countByStatut(Inscription.Statut.TERMINE));
        model.addAttribute("utilisateurs", utilisateurService.findAll());
        model.addAttribute("cours", coursService.findCatalogue(null, null, null, 0, 50, "dateCreation").getContent());
        return "admin/dashboard";
    }

    @PostMapping("/utilisateurs/{id}/toggle")
    public String toggleUtilisateur(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        utilisateurService.toggleActif(id);
        redirectAttributes.addFlashAttribute("success", "Statut utilisateur modifié.");
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/cours/{id}/supprimer")
    public String supprimerCours(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        coursService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Cours supprimé.");
        return "redirect:/admin/dashboard";
    }
}
