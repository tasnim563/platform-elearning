package com.fst.elearning.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class AvisFormDTO {
    private Long coursId;
    @Min(1) @Max(5)
    private int note;
    @Size(max = 1000)
    private String commentaire;
}
