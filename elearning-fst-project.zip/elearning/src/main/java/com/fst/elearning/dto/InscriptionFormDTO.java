package com.fst.elearning.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class InscriptionFormDTO {
    private Long coursId;
}
