package com.fst.elearning.repository;
import com.fst.elearning.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface AvisRepository extends JpaRepository<Avis, Long> {
    Optional<Avis> findByApprenantAndCours(Utilisateur apprenant, Cours cours);
    List<Avis> findByCours(Cours cours);
    boolean existsByApprenantAndCours(Utilisateur apprenant, Cours cours);
    @Query("SELECT AVG(a.note) FROM Avis a WHERE a.cours = :cours")
    Double findMoyenneNoteByCours(@Param("cours") Cours cours);
}
