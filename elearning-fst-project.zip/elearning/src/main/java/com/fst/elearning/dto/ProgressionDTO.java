package com.fst.elearning.dto;

import com.fst.elearning.entity.Inscription;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ProgressionDTO {
    private Long coursId;
    private String coursTitre;
    private String coursImage;
    private String formateurNom;
    private int pourcentage;
    private int leconCompletees;
    private int totalLecons;
    private Inscription.Statut statut;
}
