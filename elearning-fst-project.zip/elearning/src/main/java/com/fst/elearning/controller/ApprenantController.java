package com.fst.elearning.controller;

import com.fst.elearning.dto.AvisFormDTO;
import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import com.fst.elearning.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/apprenant")
@PreAuthorize("hasRole('APPRENANT')")
@RequiredArgsConstructor
public class ApprenantController {

    private final UtilisateurService utilisateurService;
    private final CoursService coursService;
    private final InscriptionService inscriptionService;
    private final ProgressionService progressionService;
    private final QuizService quizService;
    private final AvisRepository avisRepository;
    private final LeconRepository leconRepository;
    private final ModuleRepository moduleRepository;

    private Utilisateur getCurrentUser(Authentication auth) {
        return utilisateurService.findByEmail(auth.getName());
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        Utilisateur user = getCurrentUser(auth);
        model.addAttribute("user", user);
        model.addAttribute("progressions", progressionService.getProgressionApprenant(user));
        model.addAttribute("inscriptions", inscriptionService.findByApprenant(user));
        return "apprenant/dashboard";
    }

    @PostMapping("/inscrire/{coursId}")
    public String inscrire(@PathVariable Long coursId, Authentication auth,
                           RedirectAttributes redirectAttributes) {
        Utilisateur user = getCurrentUser(auth);
        Cours cours = coursService.findById(coursId);
        try {
            inscriptionService.inscrire(user, cours);
            redirectAttributes.addFlashAttribute("success", "Inscription réussie à \"" + cours.getTitre() + "\" !");
        } catch (IllegalStateException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/apprenant/cours/" + coursId;
    }

    @GetMapping("/cours/{coursId}")
    public String voirCours(@PathVariable Long coursId, Authentication auth, Model model) {
        Utilisateur user = getCurrentUser(auth);
        Cours cours = coursService.findById(coursId);

        if (!inscriptionService.isInscrit(user, cours)) {
            return "redirect:/catalogue/" + coursId;
        }

        int progression = progressionService.calculerPourcentage(user, cours);
        Map<Long, Boolean> leconStatus = new HashMap<>();
        cours.getModules().forEach(m ->
            m.getLecons().forEach(l ->
                leconStatus.put(l.getId(), progressionService.isLeconComplete(user, l))
            )
        );

        model.addAttribute("cours", cours);
        model.addAttribute("user", user);
        model.addAttribute("progression", progression);
        model.addAttribute("leconStatus", leconStatus);
        model.addAttribute("avisExistant", avisRepository.findByApprenantAndCours(user, cours).orElse(null));
        return "apprenant/cours";
    }

    @GetMapping("/lecon/{leconId}")
    public String voirLecon(@PathVariable Long leconId, Authentication auth, Model model) {
        Utilisateur user = getCurrentUser(auth);
        Lecon lecon = leconRepository.findById(leconId)
            .orElseThrow(() -> new RuntimeException("Leçon non trouvée"));
        Cours cours = lecon.getModule().getCours();

        if (!inscriptionService.isInscrit(user, cours)) {
            return "redirect:/catalogue/" + cours.getId();
        }

        boolean completee = progressionService.isLeconComplete(user, lecon);
        model.addAttribute("lecon", lecon);
        model.addAttribute("cours", cours);
        model.addAttribute("user", user);
        model.addAttribute("completee", completee);
        model.addAttribute("progression", progressionService.calculerPourcentage(user, cours));
        return "apprenant/lecon";
    }

    @PostMapping("/lecon/{leconId}/complete")
    public String completeLecon(@PathVariable Long leconId, Authentication auth,
                                RedirectAttributes redirectAttributes) {
        Utilisateur user = getCurrentUser(auth);
        Lecon lecon = leconRepository.findById(leconId)
            .orElseThrow(() -> new RuntimeException("Leçon non trouvée"));
        progressionService.marquerLeconComplete(user, lecon);
        redirectAttributes.addFlashAttribute("success", "Leçon marquée comme complétée !");
        return "redirect:/apprenant/cours/" + lecon.getModule().getCours().getId();
    }

    @GetMapping("/quiz/{quizId}")
    public String voirQuiz(@PathVariable Long quizId, Authentication auth, Model model) {
        Utilisateur user = getCurrentUser(auth);
        Quiz quiz = quizService.findById(quizId);
        quizService.findResultat(user, quiz).ifPresent(r -> model.addAttribute("resultatExistant", r));
        model.addAttribute("quiz", quiz);
        model.addAttribute("user", user);
        return "apprenant/quiz";
    }

    @PostMapping("/quiz/{quizId}/soumettre")
    public String soumettreQuiz(@PathVariable Long quizId,
                                @RequestParam Map<String, String> params,
                                Authentication auth,
                                RedirectAttributes redirectAttributes) {
        Utilisateur user = getCurrentUser(auth);
        Map<Long, Character> reponses = new HashMap<>();
        params.forEach((key, val) -> {
            if (key.startsWith("question_")) {
                try {
                    Long qId = Long.parseLong(key.substring(9));
                    if (!val.isEmpty()) reponses.put(qId, val.charAt(0));
                } catch (NumberFormatException ignored) {}
            }
        });
        var result = quizService.soumettre(user, quizId, reponses);
        redirectAttributes.addFlashAttribute("quizResult", result);
        return "redirect:/apprenant/quiz/" + quizId + "/resultat";
    }

    @GetMapping("/quiz/{quizId}/resultat")
    public String resultatQuiz(@PathVariable Long quizId, Authentication auth, Model model) {
        Utilisateur user = getCurrentUser(auth);
        Quiz quiz = quizService.findById(quizId);
        quizService.findResultat(user, quiz).ifPresent(r -> model.addAttribute("resultat", r));
        model.addAttribute("quiz", quiz);
        return "apprenant/quiz-resultat";
    }

    @PostMapping("/avis")
    public String soumettreAvis(@Valid @ModelAttribute AvisFormDTO dto,
                                Authentication auth,
                                RedirectAttributes redirectAttributes) {
        Utilisateur user = getCurrentUser(auth);
        Cours cours = coursService.findById(dto.getCoursId());
        if (!avisRepository.existsByApprenantAndCours(user, cours)) {
            Avis avis = Avis.builder()
                .apprenant(user).cours(cours)
                .note(dto.getNote()).commentaire(dto.getCommentaire())
                .build();
            avisRepository.save(avis);
            redirectAttributes.addFlashAttribute("success", "Votre avis a été enregistré !");
        }
        return "redirect:/apprenant/cours/" + cours.getId();
    }

    @PostMapping("/photo")
    public String uploadPhoto(@RequestParam MultipartFile photo,
                              Authentication auth,
                              RedirectAttributes redirectAttributes) throws IOException {
        Utilisateur user = getCurrentUser(auth);
        utilisateurService.updatePhoto(user.getId(), photo);
        redirectAttributes.addFlashAttribute("success", "Photo mise à jour avec succès !");
        return "redirect:/apprenant/dashboard";
    }
}
