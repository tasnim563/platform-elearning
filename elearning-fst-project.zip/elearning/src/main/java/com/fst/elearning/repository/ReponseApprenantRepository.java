package com.fst.elearning.repository;
import com.fst.elearning.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface ReponseApprenantRepository extends JpaRepository<ReponseApprenant, Long> {
    Optional<ReponseApprenant> findByApprenantAndQuiz(Utilisateur apprenant, Quiz quiz);
    List<ReponseApprenant> findByApprenant(Utilisateur apprenant);
}
