package com.fst.elearning.controller;

import com.fst.elearning.entity.Cours;
import com.fst.elearning.entity.Utilisateur;
import com.fst.elearning.service.CoursService;
import com.fst.elearning.service.InscriptionService;
import com.fst.elearning.service.UtilisateurService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/catalogue")
@RequiredArgsConstructor
public class CatalogueController {

    private final CoursService coursService;
    private final InscriptionService inscriptionService;
    private final UtilisateurService utilisateurService;

    @GetMapping
    public String catalogue(@RequestParam(defaultValue = "") String titre,
                            @RequestParam(defaultValue = "") String categorie,
                            @RequestParam(required = false) Cours.Niveau niveau,
                            @RequestParam(defaultValue = "0") int page,
                            @RequestParam(defaultValue = "9") int size,
                            @RequestParam(defaultValue = "dateCreation") String sort,
                            Model model, Authentication auth) {

        Page<Cours> coursPage = coursService.findCatalogue(titre, categorie, niveau, page, size, sort);

        model.addAttribute("coursPage", coursPage);
        model.addAttribute("categories", coursService.findAllCategories());
        model.addAttribute("niveaux", Cours.Niveau.values());
        model.addAttribute("titre", titre);
        model.addAttribute("categorie", categorie);
        model.addAttribute("niveau", niveau);
        model.addAttribute("sort", sort);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", coursPage.getTotalPages());

        if (auth != null) {
            Utilisateur user = utilisateurService.findByEmail(auth.getName());
            model.addAttribute("currentUser", user);
        }

        return "catalogue/index";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model, Authentication auth) {
        Cours cours = coursService.findById(id);
        model.addAttribute("cours", cours);

        if (auth != null) {
            Utilisateur user = utilisateurService.findByEmail(auth.getName());
            model.addAttribute("currentUser", user);
            model.addAttribute("isInscrit", inscriptionService.isInscrit(user, cours));
        }

        return "catalogue/detail";
    }
}
