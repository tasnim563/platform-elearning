package com.fst.elearning.config;

import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.IExpressionContext;
import org.thymeleaf.dialect.AbstractDialect;
import org.thymeleaf.dialect.IExpressionObjectDialect;
import org.thymeleaf.expression.IExpressionObjectFactory;
import java.util.Collections;
import java.util.Set;

@Component
public class ThymeleafMarkdownDialect extends AbstractDialect implements IExpressionObjectDialect {

    @Autowired private Parser parser;
    @Autowired private HtmlRenderer renderer;

    public ThymeleafMarkdownDialect() { super("markdown"); }

    @Override
    public IExpressionObjectFactory getExpressionObjectFactory() {
        return new IExpressionObjectFactory() {
            @Override
            public Set<String> getAllExpressionObjectNames() {
                return Collections.singleton("markdown");
            }
            @Override
            public Object buildObject(IExpressionContext ctx, String name) {
                return new MarkdownHelper(parser, renderer);
            }
            @Override
            public boolean isCacheable(String name) { return true; }
        };
    }

    public static class MarkdownHelper {
        private final Parser parser;
        private final HtmlRenderer renderer;
        public MarkdownHelper(Parser p, HtmlRenderer r) { this.parser = p; this.renderer = r; }
        public String render(String text) {
            if (text == null || text.isBlank()) return "";
            return renderer.render(parser.parse(text));
        }
    }
}
