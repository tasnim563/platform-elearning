package com.fst.elearning.repository;
import com.fst.elearning.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface QuizRepository extends JpaRepository<Quiz, Long> {
    Optional<Quiz> findByModule(Module module);
    boolean existsByModule(Module module);
}
