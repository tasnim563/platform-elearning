package com.fst.elearning.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "questions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Question {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank @Column(nullable = false, columnDefinition = "TEXT")
    private String enonce;

    @NotBlank @Column(nullable = false)
    private String choixA;

    @NotBlank @Column(nullable = false)
    private String choixB;

    @NotBlank @Column(nullable = false)
    private String choixC;

    @NotBlank @Column(nullable = false)
    private String choixD;

    @Column(nullable = false)
    private char bonneReponse; // 'A', 'B', 'C', 'D'

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id", nullable = false)
    private Quiz quiz;

    public String getChoixParLettre(char lettre) {
        return switch (lettre) {
            case 'A' -> choixA;
            case 'B' -> choixB;
            case 'C' -> choixC;
            case 'D' -> choixD;
            default -> "";
        };
    }
}
