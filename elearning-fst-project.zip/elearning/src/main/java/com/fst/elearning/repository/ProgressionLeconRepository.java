package com.fst.elearning.repository;
import com.fst.elearning.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface ProgressionLeconRepository extends JpaRepository<ProgressionLecon, Long> {
    Optional<ProgressionLecon> findByApprenantAndLecon(Utilisateur apprenant, Lecon lecon);

    @Query("""
        SELECT COUNT(pl) FROM ProgressionLecon pl
        JOIN pl.lecon l JOIN l.module m
        WHERE pl.apprenant = :apprenant AND m.cours = :cours AND pl.completee = true
    """)
    long countLeconCompleteesByCours(@Param("apprenant") Utilisateur apprenant, @Param("cours") Cours cours);

    @Query("SELECT COUNT(l) FROM Lecon l JOIN l.module m WHERE m.cours = :cours")
    long countTotalLeconsByCours(@Param("cours") Cours cours);

    boolean existsByApprenantAndLecon(Utilisateur apprenant, Lecon lecon);
}
