package com.fst.elearning.dto;

import com.fst.elearning.entity.Utilisateur;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class RegistrationDTO {
    @NotBlank @Size(min=2, max=50)
    private String nom;
    @NotBlank @Size(min=2, max=50)
    private String prenom;
    @Email @NotBlank
    private String email;
    @NotBlank @Size(min=6, max=100)
    private String motDePasse;
    @NotBlank
    private String confirmMotDePasse;
    private Utilisateur.Role role = Utilisateur.Role.APPRENANT;

    public boolean isMotDePasseMatch() {
        return motDePasse != null && motDePasse.equals(confirmMotDePasse);
    }
}
