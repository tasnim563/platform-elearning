package com.fst.elearning.service;

import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class CoursService {

    private final CoursRepository coursRepository;
    private final FileStorageService fileStorageService;

    @Transactional(readOnly = true)
    public Page<Cours> findCatalogue(String titre, String categorie, Cours.Niveau niveau,
                                     int page, int size, String sort) {
        Pageable pageable = PageRequest.of(page, size,
            sort.equals("titre") ? Sort.by("titre") : Sort.by("dateCreation").descending());
        String titreFilter = (titre != null && !titre.isBlank()) ? titre : null;
        String categorieFilter = (categorie != null && !categorie.isBlank()) ? categorie : null;
        Cours.Niveau niveauFilter = null;
        if (niveau != null) niveauFilter = niveau;
        return coursRepository.findWithFilters(titreFilter, categorieFilter, niveauFilter, pageable);
    }

    @Transactional(readOnly = true)
    public Cours findById(Long id) {
        return coursRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Cours non trouvé: " + id));
    }

    public Cours save(Cours cours, MultipartFile image) throws IOException {
        if (image != null && !image.isEmpty()) {
            if (cours.getImageUrl() != null) fileStorageService.delete(cours.getImageUrl());
            cours.setImageUrl(fileStorageService.store(image, "cours"));
        }
        return coursRepository.save(cours);
    }

    public void delete(Long id) {
        Cours cours = findById(id);
        if (cours.getImageUrl() != null) fileStorageService.delete(cours.getImageUrl());
        coursRepository.delete(cours);
    }

    @Transactional(readOnly = true)
    public List<Cours> findByFormateur(Utilisateur formateur) {
        return coursRepository.findByFormateurAndActifTrue(formateur);
    }

    @Transactional(readOnly = true)
    public List<String> findAllCategories() { return coursRepository.findAllCategories(); }

    @Transactional(readOnly = true)
    public long countActifs() { return coursRepository.countByActifTrue(); }
}
