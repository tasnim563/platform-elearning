package com.fst.elearning.repository;
import com.fst.elearning.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface InscriptionRepository extends JpaRepository<Inscription, Long> {
    Optional<Inscription> findByApprenantAndCours(Utilisateur apprenant, Cours cours);
    boolean existsByApprenantAndCours(Utilisateur apprenant, Cours cours);
    List<Inscription> findByApprenant(Utilisateur apprenant);
    List<Inscription> findByCours(Cours cours);
    long countByStatut(Inscription.Statut statut);
}
