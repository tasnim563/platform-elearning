package com.fst.elearning.service;

import com.fst.elearning.dto.ProgressionDTO;
import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional
public class ProgressionService {

    private final ProgressionLeconRepository progressionRepo;
    private final InscriptionRepository inscriptionRepo;
    private final LeconRepository leconRepo;

    public void marquerLeconComplete(Utilisateur apprenant, Lecon lecon) {
        progressionRepo.findByApprenantAndLecon(apprenant, lecon).ifPresentOrElse(
            p -> { p.marquerComplete(); progressionRepo.save(p); },
            () -> {
                ProgressionLecon p = ProgressionLecon.builder()
                    .apprenant(apprenant).lecon(lecon).build();
                p.marquerComplete();
                progressionRepo.save(p);
            }
        );
        updateStatutInscription(apprenant, lecon.getModule().getCours());
    }

    @Transactional(readOnly = true)
    public int calculerPourcentage(Utilisateur apprenant, Cours cours) {
        long total = progressionRepo.countTotalLeconsByCours(cours);
        if (total == 0) return 0;
        long completees = progressionRepo.countLeconCompleteesByCours(apprenant, cours);
        return (int) Math.round((double) completees / total * 100);
    }

    @Transactional(readOnly = true)
    public boolean isLeconComplete(Utilisateur apprenant, Lecon lecon) {
        return progressionRepo.findByApprenantAndLecon(apprenant, lecon)
            .map(ProgressionLecon::isCompletee).orElse(false);
    }

    @Transactional(readOnly = true)
    public List<ProgressionDTO> getProgressionApprenant(Utilisateur apprenant) {
        List<Inscription> inscriptions = inscriptionRepo.findByApprenant(apprenant);
        List<ProgressionDTO> result = new ArrayList<>();
        for (Inscription ins : inscriptions) {
            Cours cours = ins.getCours();
            long total = progressionRepo.countTotalLeconsByCours(cours);
            long completees = progressionRepo.countLeconCompleteesByCours(apprenant, cours);
            int pct = total == 0 ? 0 : (int) Math.round((double) completees / total * 100);
            result.add(ProgressionDTO.builder()
                .coursId(cours.getId())
                .coursTitre(cours.getTitre())
                .coursImage(cours.getImageUrl())
                .formateurNom(cours.getFormateur().getNomComplet())
                .pourcentage(pct)
                .leconCompletees((int) completees)
                .totalLecons((int) total)
                .statut(ins.getStatut())
                .build());
        }
        return result;
    }

    private void updateStatutInscription(Utilisateur apprenant, Cours cours) {
        inscriptionRepo.findByApprenantAndCours(apprenant, cours).ifPresent(ins -> {
            int pct = calculerPourcentage(apprenant, cours);
            if (pct == 100) {
                ins.setStatut(Inscription.Statut.TERMINE);
                inscriptionRepo.save(ins);
            }
        });
    }
}
