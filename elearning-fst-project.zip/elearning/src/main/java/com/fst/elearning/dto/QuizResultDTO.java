package com.fst.elearning.dto;

import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class QuizResultDTO {
    private Long quizId;
    private String quizTitre;
    private String moduleTitre;
    private String coursTitre;
    private int score;
    private int totalQuestions;
    private double pourcentage;
    private boolean reussi;
    private LocalDateTime dateSoumission;
}
