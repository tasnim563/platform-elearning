package com.fst.elearning.repository;
import com.fst.elearning.entity.Cours;
import com.fst.elearning.entity.Utilisateur;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CoursRepository extends JpaRepository<Cours, Long> {
    Page<Cours> findByActifTrue(Pageable pageable);

    @Query("""
        SELECT c FROM Cours c WHERE c.actif = true
        AND (:titre IS NULL OR LOWER(c.titre) LIKE LOWER(CONCAT('%',:titre,'%')))
        AND (:categorie IS NULL OR c.categorie = :categorie)
        AND (:niveau IS NULL OR c.niveau = :niveau)
    """)
    Page<Cours> findWithFilters(@Param("titre") String titre,
        @Param("categorie") String categorie,
        @Param("niveau") Cours.Niveau niveau, Pageable pageable);

    List<Cours> findByFormateurAndActifTrue(Utilisateur formateur);

    @Query("SELECT DISTINCT c.categorie FROM Cours c WHERE c.actif = true ORDER BY c.categorie")
    List<String> findAllCategories();

    long countByActifTrue();
}
