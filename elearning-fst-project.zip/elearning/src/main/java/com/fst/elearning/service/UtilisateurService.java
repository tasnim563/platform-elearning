package com.fst.elearning.service;

import com.fst.elearning.dto.RegistrationDTO;
import com.fst.elearning.entity.Utilisateur;
import com.fst.elearning.repository.UtilisateurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class UtilisateurService {

    private final UtilisateurRepository utilisateurRepository;
    private final PasswordEncoder passwordEncoder;
    private final FileStorageService fileStorageService;

    public Utilisateur findByEmail(String email) {
        return utilisateurRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));
    }

    public Utilisateur findById(Long id) {
        return utilisateurRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé: " + id));
    }

    public Utilisateur register(RegistrationDTO dto) {
        if (utilisateurRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Cet email est déjà utilisé");
        }
        if (!dto.isMotDePasseMatch()) {
            throw new IllegalArgumentException("Les mots de passe ne correspondent pas");
        }
        Utilisateur user = Utilisateur.builder()
            .nom(dto.getNom())
            .prenom(dto.getPrenom())
            .email(dto.getEmail())
            .motDePasse(passwordEncoder.encode(dto.getMotDePasse()))
            .role(dto.getRole())
            .actif(true)
            .build();
        return utilisateurRepository.save(user);
    }

    public Utilisateur updatePhoto(Long id, MultipartFile photo) throws IOException {
        Utilisateur user = findById(id);
        if (user.getPhotoUrl() != null) fileStorageService.delete(user.getPhotoUrl());
        String url = fileStorageService.store(photo, "avatars");
        user.setPhotoUrl(url);
        return utilisateurRepository.save(user);
    }

    public List<Utilisateur> findAll() { return utilisateurRepository.findAll(); }

    public void toggleActif(Long id) {
        Utilisateur u = findById(id);
        u.setActif(!u.isActif());
        utilisateurRepository.save(u);
    }

    public long countByRole(Utilisateur.Role role) { return utilisateurRepository.countByRole(role); }
}
