package com.fst.elearning.service;

import com.fst.elearning.entity.*;
import com.fst.elearning.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class InscriptionService {

    private final InscriptionRepository inscriptionRepo;

    public Inscription inscrire(Utilisateur apprenant, Cours cours) {
        if (inscriptionRepo.existsByApprenantAndCours(apprenant, cours)) {
            throw new IllegalStateException("Vous êtes déjà inscrit à ce cours");
        }
        return inscriptionRepo.save(Inscription.builder()
            .apprenant(apprenant).cours(cours).build());
    }

    @Transactional(readOnly = true)
    public boolean isInscrit(Utilisateur apprenant, Cours cours) {
        return inscriptionRepo.existsByApprenantAndCours(apprenant, cours);
    }

    @Transactional(readOnly = true)
    public List<Inscription> findByApprenant(Utilisateur apprenant) {
        return inscriptionRepo.findByApprenant(apprenant);
    }

    @Transactional(readOnly = true)
    public List<Inscription> findByCours(Cours cours) {
        return inscriptionRepo.findByCours(cours);
    }

    public void desinscrire(Utilisateur apprenant, Cours cours) {
        inscriptionRepo.findByApprenantAndCours(apprenant, cours).ifPresent(ins -> {
            ins.setStatut(Inscription.Statut.ABANDONNE);
            inscriptionRepo.save(ins);
        });
    }
}
