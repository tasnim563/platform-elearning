package com.fst.elearning.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reponses_apprenants")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ReponseApprenant {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "apprenant_id", nullable = false)
    private Utilisateur apprenant;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id", nullable = false)
    private Quiz quiz;

    @Column(nullable = false)
    private int score;

    @Column(nullable = false)
    private int totalQuestions;

    @Column(nullable = false)
    private LocalDateTime dateSoumission = LocalDateTime.now();

    public double getPourcentage() {
        return totalQuestions == 0 ? 0 : (double) score / totalQuestions * 100;
    }

    public boolean isReussi() { return getPourcentage() >= 60; }
}
