package com.fst.elearning.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "avis", uniqueConstraints = @UniqueConstraint(columnNames = {"apprenant_id","cours_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Avis {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "apprenant_id", nullable = false)
    private Utilisateur apprenant;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cours_id", nullable = false)
    private Cours cours;

    @Min(1) @Max(5)
    @Column(nullable = false)
    private int note;

    @Size(max = 1000)
    @Column(columnDefinition = "TEXT")
    private String commentaire;

    @Column(nullable = false)
    private LocalDateTime dateAvis = LocalDateTime.now();
}
