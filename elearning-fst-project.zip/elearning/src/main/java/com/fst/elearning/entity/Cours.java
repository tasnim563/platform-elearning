package com.fst.elearning.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cours")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Cours {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min = 3, max = 150)
    @Column(nullable = false)
    private String titre;

    @NotBlank
    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;

    @NotBlank
    @Column(nullable = false)
    private String categorie;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Niveau niveau;

    @Column
    private String imageUrl;

    @Column(nullable = false)
    private boolean actif = true;

    @Column(nullable = false)
    private LocalDateTime dateCreation = LocalDateTime.now();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "formateur_id", nullable = false)
    private Utilisateur formateur;

    @OneToMany(mappedBy = "cours", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("ordre ASC")
    @Builder.Default
    private List<Module> modules = new ArrayList<>();

    @OneToMany(mappedBy = "cours", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @Builder.Default
    private List<Inscription> inscriptions = new ArrayList<>();

    @OneToMany(mappedBy = "cours", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @Builder.Default
    private List<Avis> avis = new ArrayList<>();

    public int getNombreModules() {
        return modules != null ? modules.size() : 0;
    }

    public int getNombreLecons() {
        return modules != null ? modules.stream()
                .mapToInt(m -> m.getLecons() != null ? m.getLecons().size() : 0).sum() : 0;
    }

    public int getNombreInscrits() {
        return inscriptions != null ? inscriptions.size() : 0;
    }

    public double getMoyenneAvis() {
        if (avis == null || avis.isEmpty()) return 0;
        return avis.stream().mapToInt(Avis::getNote).average().orElse(0);
    }

    public enum Niveau {
        DEBUTANT, INTERMEDIAIRE, AVANCE;

        public String getLibelle() {
            return switch (this) {
                case DEBUTANT -> "Débutant";
                case INTERMEDIAIRE -> "Intermédiaire";
                case AVANCE -> "Avancé";
            };
        }

        public String getBadgeClass() {
            return switch (this) {
                case DEBUTANT -> "badge-success";
                case INTERMEDIAIRE -> "badge-warning";
                case AVANCE -> "badge-danger";
            };
        }
    }
}
