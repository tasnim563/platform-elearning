/* ELearn FST — Main JS */

/* Auto-dismiss alerts after 5s */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.alert.fade.show').forEach(alert => {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      bsAlert.close();
    }, 5000);
  });

  /* Activate current nav link based on URL */
  const path = window.location.pathname;
  document.querySelectorAll('.fst-navbar .nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && path.startsWith(href) && href !== '/') {
      link.classList.add('active');
      link.style.color = '#fff';
      link.style.background = 'rgba(255,255,255,0.12)';
    }
  });

  /* Tooltips */
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
    new bootstrap.Tooltip(el);
  });

  /* Confirm delete buttons */
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', e => {
      if (!confirm(form.dataset.confirm)) e.preventDefault();
    });
  });

  /* Progress bar animations on load */
  document.querySelectorAll('.progress-bar').forEach(bar => {
    const target = bar.style.width;
    bar.style.width = '0';
    setTimeout(() => {
      bar.style.transition = 'width 1s ease';
      bar.style.width = target;
    }, 100);
  });
});
