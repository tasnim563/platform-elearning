-- ============================================================
-- ELearn FST — Données initiales (data.sql)
-- Master STR · 2025/2026
-- Mot de passe pour tous les comptes : Password123!
-- (BCrypt hash of "Password123!")
-- ============================================================

-- Utilisateurs (password = "Password123!" BCrypt)
INSERT IGNORE INTO utilisateurs (id, nom, prenom, email, mot_de_passe, role, actif, date_creation) VALUES
(1, 'Belhadj', 'Nader',    'admin@fst.tn',     '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/.',  'ADMIN',     true, NOW()),
(2, 'Ben Ali', 'Karim',    'karim@fst.tn',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/.', 'FORMATEUR', true, NOW()),
(3, 'Trabelsi','Sonia',    'sonia@fst.tn',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/.', 'FORMATEUR', true, NOW()),
(4, 'Mansouri','Ahmed',    'ahmed@fst.tn',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/.', 'APPRENANT', true, NOW()),
(5, 'Jebali',  'Rania',    'rania@fst.tn',      '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/.', 'APPRENANT', true, NOW()),
(6, 'Kouki',   'Yassine',  'yassine@fst.tn',    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/.', 'APPRENANT', true, NOW());

-- ============================================================
-- COURS 1 : Spring Boot
-- ============================================================
INSERT IGNORE INTO cours (id, titre, description, categorie, niveau, image_url, actif, date_creation, formateur_id) VALUES
(1, 'Développement Web avec Spring Boot 3',
 'Maîtrisez Spring Boot 3, Spring MVC, Spring Data JPA et Spring Security pour créer des applications web professionnelles. Ce cours couvre toute la stack de bout en bout avec des exercices pratiques et un projet fil rouge complet.',
 'Développement Web', 'INTERMEDIAIRE', NULL, true, NOW(), 2);

-- Modules Cours 1
INSERT IGNORE INTO modules (id, titre, description, ordre, cours_id) VALUES
(1, 'Introduction à Spring Boot', 'Découverte de l''écosystème Spring et configuration initiale', 1, 1),
(2, 'Spring MVC et Thymeleaf',    'Création de contrôleurs, vues et gestion des formulaires',    2, 1),
(3, 'Spring Data JPA et MySQL',   'Persistance des données avec JPA, Hibernate et MySQL',         3, 1);

-- Leçons Module 1
INSERT IGNORE INTO lecons (id, titre, contenu, ordre, duree_min, module_id) VALUES
(1, 'Qu''est-ce que Spring Boot ?',
'# Qu''est-ce que Spring Boot ?

Spring Boot est un framework Java qui simplifie la création d''applications Spring autonomes et production-ready.

## Avantages clés

- **Auto-configuration** : Spring Boot configure automatiquement votre application
- **Starters** : Dépendances groupées par fonctionnalité
- **Embedded server** : Tomcat intégré, pas besoin de déploiement WAR
- **Actuator** : Monitoring et métriques intégrés

## Votre première application

```java
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

> Spring Boot suit la convention over configuration pour accélérer le développement.',
1, 20, 1),

(2, 'Structure d''un projet Spring Boot',
'# Structure d''un projet Spring Boot

## Architecture recommandée

```
src/main/java/com/example/
├── controller/     ← Contrôleurs MVC
├── service/        ← Logique métier
├── repository/     ← Accès aux données
├── entity/         ← Entités JPA
└── config/         ← Configurations
```

## Le fichier application.properties

```properties
server.port=8080
spring.datasource.url=jdbc:mysql://localhost:3306/mydb
spring.jpa.hibernate.ddl-auto=update
```

Chaque propriété configure un aspect de l''application de manière déclarative.',
2, 15, 1),

(3, 'Injection de dépendances avec Spring',
'# Injection de dépendances

## Le principe fondamental

L''IoC (Inversion of Control) délègue la création des objets au conteneur Spring.

```java
@Service
@RequiredArgsConstructor
public class CoursService {
    private final CoursRepository repository; // Injecté automatiquement
    
    public List<Cours> findAll() {
        return repository.findAll();
    }
}
```

## Annotations principales

| Annotation | Rôle |
|-----------|------|
| `@Component` | Bean générique |
| `@Service` | Couche service |
| `@Repository` | Couche données |
| `@Controller` | Contrôleur MVC |',
3, 25, 1);

-- Leçons Module 2
INSERT IGNORE INTO lecons (id, titre, contenu, ordre, duree_min, module_id) VALUES
(4, 'Créer un contrôleur Spring MVC',
'# Contrôleurs Spring MVC

## Anatomie d''un contrôleur

```java
@Controller
@RequestMapping("/cours")
@RequiredArgsConstructor
public class CoursController {

    private final CoursService coursService;

    @GetMapping
    public String liste(Model model) {
        model.addAttribute("cours", coursService.findAll());
        return "cours/liste"; // → templates/cours/liste.html
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        model.addAttribute("cours", coursService.findById(id));
        return "cours/detail";
    }
}
```

## Gestion des formulaires POST

```java
@PostMapping("/nouveau")
public String creer(@Valid @ModelAttribute Cours cours,
                    BindingResult result) {
    if (result.hasErrors()) return "cours/form";
    coursService.save(cours);
    return "redirect:/cours";
}
```',
1, 30, 2),

(5, 'Templates Thymeleaf avancés',
'# Templates Thymeleaf

## Expressions essentielles

```html
<!-- Variable -->
<p th:text="${cours.titre}">Titre</p>

<!-- URL -->
<a th:href="@{/cours/{id}(id=${cours.id})}">Voir</a>

<!-- Condition -->
<div th:if="${user != null}">Connecté</div>

<!-- Boucle -->
<tr th:each="c : ${cours}">
  <td th:text="${c.titre}"></td>
</tr>
```

## Layout Dialect

```html
<!-- layout.html -->
<main layout:fragment="content"></main>

<!-- page.html -->
<html layout:decorate="~{layout}">
  <div layout:fragment="content">Contenu ici</div>
</html>
```',
2, 25, 2),

(6, 'Gestion des fichiers upload',
'# Upload de fichiers avec Spring

## Configuration

```properties
spring.servlet.multipart.max-file-size=5MB
spring.servlet.multipart.max-request-size=10MB
```

## Contrôleur

```java
@PostMapping("/upload")
public String upload(@RequestParam MultipartFile file,
                     RedirectAttributes ra) throws IOException {
    if (file.isEmpty()) {
        ra.addFlashAttribute("error", "Fichier vide");
        return "redirect:/upload";
    }
    
    String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
    Path dest = Paths.get("uploads").resolve(filename);
    Files.copy(file.getInputStream(), dest, REPLACE_EXISTING);
    
    ra.addFlashAttribute("success", "Fichier uploadé !");
    return "redirect:/upload";
}
```

## Template Thymeleaf

```html
<form th:action="@{/upload}" method="post" enctype="multipart/form-data">
  <input type="file" name="file" accept="image/*"/>
  <button type="submit">Uploader</button>
</form>
```',
3, 20, 2);

-- Leçons Module 3
INSERT IGNORE INTO lecons (id, titre, contenu, ordre, duree_min, module_id) VALUES
(7, 'Entités JPA et relations',
'# Entités JPA

## Annotations de base

```java
@Entity
@Table(name = "cours")
public class Cours {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String titre;
    
    @Enumerated(EnumType.STRING)
    private Niveau niveau;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "formateur_id")
    private Utilisateur formateur;
    
    @OneToMany(mappedBy = "cours", cascade = CascadeType.ALL)
    private List<Module> modules = new ArrayList<>();
}
```

## Types de relations

| Relation | Annotation |
|---------|-----------|
| Un-à-plusieurs | `@OneToMany` |
| Plusieurs-à-un | `@ManyToOne` |
| Plusieurs-à-plusieurs | `@ManyToMany` |
| Un-à-un | `@OneToOne` |',
1, 35, 3),

(8, 'Spring Data JPA et JPQL',
'# Spring Data JPA

## Repository de base

```java
@Repository
public interface CoursRepository extends JpaRepository<Cours, Long> {
    // Méthodes dérivées
    List<Cours> findByActifTrue();
    List<Cours> findByNiveau(Cours.Niveau niveau);
    
    // Requête JPQL personnalisée
    @Query("""
        SELECT c FROM Cours c
        WHERE c.actif = true
        AND LOWER(c.titre) LIKE LOWER(CONCAT(''%'',:titre,''%''))
    """)
    Page<Cours> searchByTitre(@Param("titre") String titre, Pageable pageable);
}
```

## Pagination avec Pageable

```java
// Dans le service
Page<Cours> page = coursRepository.findByActifTrue(
    PageRequest.of(0, 9, Sort.by("dateCreation").descending())
);
```',
2, 30, 3),

(9, 'Spring Security : authentification et rôles',
'# Spring Security 6

## Configuration moderne

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/formateur/**").hasAnyRole("FORMATEUR","ADMIN")
                .requestMatchers("/", "/catalogue/**").permitAll()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/auth/login")
                .defaultSuccessUrl("/dashboard")
            );
        return http.build();
    }
}
```

## Thymeleaf Security

```html
<div sec:authorize="hasRole(''ADMIN'')">Admin seulement</div>
<span sec:authentication="principal.username">email</span>
```',
3, 40, 3);

-- ============================================================
-- COURS 2 : Intelligence Artificielle
-- ============================================================
INSERT IGNORE INTO cours (id, titre, description, categorie, niveau, image_url, actif, date_creation, formateur_id) VALUES
(2, 'Introduction à l''Intelligence Artificielle',
 'Découvrez les fondamentaux de l''IA : machine learning, deep learning, traitement du langage naturel et vision par ordinateur. Un cours pratique avec Python et des cas d''usage réels du monde professionnel.',
 'Intelligence Artificielle', 'DEBUTANT', NULL, true, NOW(), 3);

INSERT IGNORE INTO modules (id, titre, description, ordre, cours_id) VALUES
(4, 'Fondamentaux du Machine Learning', 'Algorithmes supervisés et non supervisés', 1, 2),
(5, 'Deep Learning avec Python',        'Réseaux de neurones et frameworks modernes', 2, 2);

INSERT IGNORE INTO lecons (id, titre, contenu, ordre, duree_min, module_id) VALUES
(10, 'Qu''est-ce que le Machine Learning ?',
'# Machine Learning

Le Machine Learning est un sous-domaine de l''IA permettant aux machines d''apprendre automatiquement à partir des données.

## Types d''apprentissage

- **Supervisé** : apprentissage avec données étiquetées (classification, régression)
- **Non supervisé** : découverte de structures cachées (clustering)
- **Par renforcement** : apprentissage par essai-erreur

## Exemple avec Scikit-learn

```python
from sklearn.linear_model import LinearRegression
import numpy as np

X = np.array([[1], [2], [3], [4]])
y = np.array([2, 4, 6, 8])

model = LinearRegression()
model.fit(X, y)
print(model.predict([[5]]))  # [10.]
```',
1, 30, 4),

(11, 'Algorithmes de classification', 'Contenu à venir - KNN, SVM, Arbres de décision', 2, 25, 4),
(12, 'Arbres de décision et Random Forest', 'Contenu à venir - Ensemble methods', 3, 35, 4),
(13, 'Introduction aux réseaux de neurones', 'Contenu à venir - Perceptron, backpropagation', 1, 40, 5),
(14, 'Convolutional Neural Networks (CNN)', 'Contenu à venir - Architecture CNN pour la vision', 2, 45, 5),
(15, 'Transfer Learning et fine-tuning',    'Contenu à venir - Réutilisation de modèles pré-entraînés', 3, 30, 5);

-- ============================================================
-- COURS 3 : DevOps et Docker
-- ============================================================
INSERT IGNORE INTO cours (id, titre, description, categorie, niveau, image_url, actif, date_creation, formateur_id) VALUES
(3, 'DevOps : Docker, CI/CD et Kubernetes',
 'Maîtrisez les pratiques DevOps modernes : containerisation avec Docker, pipelines CI/CD avec GitHub Actions, et orchestration avec Kubernetes. Un cours orienté pratique avec des labs concrets.',
 'DevOps', 'AVANCE', NULL, true, NOW(), 2);

INSERT IGNORE INTO modules (id, titre, description, ordre, cours_id) VALUES
(6, 'Docker et Containerisation', 'Images, conteneurs, Docker Compose', 1, 3),
(7, 'CI/CD avec GitHub Actions',  'Automatisation des tests et déploiements', 2, 3);

INSERT IGNORE INTO lecons (id, titre, contenu, ordre, duree_min, module_id) VALUES
(16, 'Introduction à Docker',
'# Docker

## Concepts fondamentaux

- **Image** : modèle read-only pour créer des conteneurs
- **Conteneur** : instance en cours d''exécution d''une image
- **Dockerfile** : instructions pour construire une image
- **Registry** : dépôt d''images (Docker Hub, ECR...)

## Dockerfile pour Spring Boot

```dockerfile
FROM eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY target/elearning-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

## Commandes essentielles

```bash
docker build -t elearning-fst .
docker run -p 8080:8080 elearning-fst
docker-compose up -d
```',
1, 35, 6),
(17, 'Docker Compose multi-services', 'Contenu à venir - Spring Boot + MySQL + Nginx', 2, 30, 6),
(18, 'GitHub Actions Pipeline', 'Contenu à venir - Build, test, deploy automatiques', 1, 40, 7),
(19, 'Déploiement sur VPS Linux', 'Contenu à venir - Nginx reverse proxy, SSL', 2, 35, 7),
(20, 'Monitoring avec Prometheus et Grafana', 'Contenu à venir - Métriques et dashboards', 3, 30, 7);

-- ============================================================
-- QUIZ Module 1 (Spring Boot Intro)
-- ============================================================
INSERT IGNORE INTO quizzes (id, titre, description, module_id) VALUES
(1, 'Quiz — Introduction à Spring Boot',
 'Testez vos connaissances sur les fondamentaux de Spring Boot', 1);

INSERT IGNORE INTO questions (id, enonce, choix_a, choix_b, choix_c, choix_d, bonne_reponse, quiz_id) VALUES
(1,  'Quelle annotation déclare la classe principale d''une application Spring Boot ?',
     '@SpringBootApplication', '@SpringMVC', '@EnableAutoConfig', '@SpringMain', 'A', 1),
(2,  'Quel serveur est intégré par défaut dans Spring Boot ?',
     'Jetty', 'WildFly', 'Tomcat', 'GlassFish', 'C', 1),
(3,  'Quel fichier contient la configuration principale d''une application Spring Boot ?',
     'web.xml', 'application.properties', 'spring.xml', 'pom.xml', 'B', 1),
(4,  'Quelle annotation permet d''injecter automatiquement une dépendance ?',
     '@Component', '@Bean', '@Autowired', '@Inject', 'C', 1),
(5,  'Que fait @SpringBootApplication ?',
     'Configure Spring Security', 'Lance Tomcat',
     'Combine @Configuration + @ComponentScan + @EnableAutoConfiguration', 'Crée la base de données', 'C', 1),
(6,  'Quelle commande Maven lance une application Spring Boot ?',
     'mvn spring:run', 'mvn boot:start', 'mvn spring-boot:run', 'mvn app:launch', 'C', 1);

-- ============================================================
-- QUIZ Module 4 (Machine Learning)
-- ============================================================
INSERT IGNORE INTO quizzes (id, titre, description, module_id) VALUES
(2, 'Quiz — Fondamentaux ML',
 'Évaluez votre compréhension du Machine Learning', 4);

INSERT IGNORE INTO questions (id, enonce, choix_a, choix_b, choix_c, choix_d, bonne_reponse, quiz_id) VALUES
(7,  'Quelle bibliothèque Python est la plus utilisée pour le Machine Learning classique ?',
     'TensorFlow', 'Scikit-learn', 'Keras', 'PyTorch', 'B', 2),
(8,  'L''apprentissage supervisé nécessite :',
     'Des données non étiquetées', 'Un agent et un environnement',
     'Des données étiquetées', 'Une connexion internet', 'C', 2),
(9,  'Quel algorithme est utilisé pour la régression linéaire ?',
     'K-Means', 'Random Forest', 'LinearRegression', 'DBSCAN', 'C', 2),
(10, 'Qu''est-ce que l''overfitting ?',
     'Le modèle est trop simple', 'Le modèle mémorise les données d''entraînement',
     'Le modèle ne converge pas', 'Le dataset est trop petit', 'B', 2),
(11, 'Le clustering est un type d''apprentissage :',
     'Supervisé', 'Par renforcement', 'Non supervisé', 'Semi-supervisé', 'C', 2);

-- ============================================================
-- Inscriptions et progressions initiales
-- ============================================================
INSERT IGNORE INTO inscriptions (id, apprenant_id, cours_id, date_inscription, statut) VALUES
(1, 4, 1, CURDATE(), 'EN_COURS'),
(2, 4, 2, CURDATE(), 'EN_COURS'),
(3, 5, 1, CURDATE(), 'EN_COURS'),
(4, 6, 3, CURDATE(), 'EN_COURS');

-- Progressions apprenant Ahmed (id=4) sur cours 1
INSERT IGNORE INTO progression_lecons (id, apprenant_id, lecon_id, completee, date_completion) VALUES
(1, 4, 1, true, NOW()),
(2, 4, 2, true, NOW()),
(3, 4, 3, true, NOW()),
(4, 4, 4, true, NOW());

-- Avis
INSERT IGNORE INTO avis (id, apprenant_id, cours_id, note, commentaire, date_avis) VALUES
(1, 4, 1, 5, 'Excellent cours ! Très bien structuré et les exemples de code sont très clairs.', NOW()),
(2, 5, 1, 4, 'Très bon contenu, j''aurais aimé plus d''exercices pratiques.', NOW());
