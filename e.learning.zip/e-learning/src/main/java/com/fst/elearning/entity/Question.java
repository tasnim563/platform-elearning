package com.fst.elearning.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Question {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String intitule;

    @ElementCollection
    private List<String> choix;

    private int bonneReponse; // index du bon choix

    @ManyToOne
    @JoinColumn(name = "quiz_id")
    private Quiz quiz;

    // ✅ Getter et Setter
    public int getBonneReponse() {
        return bonneReponse;
    }

    public void setBonneReponse(int bonneReponse) {
        this.bonneReponse = bonneReponse;
    }
}
