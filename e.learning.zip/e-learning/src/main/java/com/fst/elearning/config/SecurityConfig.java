package com.fst.elearning.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/catalogue", "/quiz/**").permitAll() // accès libre
                        .requestMatchers("/formateur/**").hasRole("FORMATEUR")
                        .requestMatchers("/apprenant/**").hasRole("APPRENANT")
                        .anyRequest().authenticated()
                )
                .formLogin(login -> login
                        .loginPage("/login")       // page de connexion personnalisée
                        .defaultSuccessUrl("/catalogue", true) // redirection après succès
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

        return http.build();
    }
}
