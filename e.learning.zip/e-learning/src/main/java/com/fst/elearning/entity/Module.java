package com.fst.elearning.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Module {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titre;
    private String description;
    private int ordre;

    @ManyToOne
    private Cours cours;

    @OneToMany(mappedBy="module", cascade=CascadeType.ALL)
    private List<Lecon> lecons;

    // Getters & Setters
}
