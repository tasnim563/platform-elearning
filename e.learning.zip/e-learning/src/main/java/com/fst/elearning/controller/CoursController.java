package com.fst.elearning.controller;

import com.fst.elearning.repository.CoursRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CoursController {
    @Autowired
    private CoursRepository coursRepo;

    @GetMapping("/catalogue")
    public String catalogue(Model model, Pageable pageable) {
        model.addAttribute("cours", coursRepo.findAll(pageable));
        return "catalogue";
    }
}
