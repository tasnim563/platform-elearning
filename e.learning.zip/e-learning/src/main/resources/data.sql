INSERT INTO utilisateur (id, nom, email, mot_de_passe, role) VALUES (1, 'Ghada', 'ghada@test.com', '1234', 'APPRENANT');
INSERT INTO cours (id, titre, description, categorie, niveau, actif, date_creation, formateur_id)
VALUES (1, 'Java Spring Boot', 'Cours complet sur Spring Boot', 'Programmation', 'DEBUTANT', true, NOW(), 1);
